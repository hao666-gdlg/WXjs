﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WechatSDK
{
    public static class SiteSettings
    {
        public static string wxAppId = "";
        public static string wxAppSecret = "";
    }
}
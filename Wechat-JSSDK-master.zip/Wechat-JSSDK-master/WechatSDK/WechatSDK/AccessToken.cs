﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WechatSDK
{
    public class AccessToken
    {
        public string access_token { get; set; }

        public double expires_in { get; set; }
    }
}